# coding: utf-8

# %% Import du  module random
import random

# %% Définition des constantes globales
MAL_PLACE = '+'
ABSENT = '*'

# %% Définition des fonctions Outils


def charger_dico(dico_path, taille_secret):
    """
    Ouvre le dictionnaire de mots de chemin dico_path
    Précondition : un mot par ligne sans accent dans le fichier
    Extrait les mots de taille_secret lettres dans l'ordre
    Renvoie un tableau de mots

    Parametres:
        dico_path (str): chemin vers le fichier de mots
    Retour:
        tableau (list) de mots (str)
    """
    f = open(dico_path)
    tab_mots = []
    # à compléter
    f.close()
    return tab_mots


def histogramme_dico(dico_path):
    """
    Renvoie un histogramme du nombre de mots par taille de mot
    dans le dictionnaire    accessible par dico_path

    Parametre:
        dico_path (str): chemin d'accès au fichier texte contenant les mots
    Retour:
        (dict) : dictionnaire de clef = taille  et valeur = nb occurrences
    """
    # à compléter


def tirage_mot(tab):
    """
    Sélectionne un mot au hasard dans le tableau de mots tab
    Précondition : tab est un tableau de mots (str) sans accents

    Parametres:
        tab (list): tableau de mots (str)
    Retour:
        un mot (str) choisi dans tab
    """
    # à compléter


def rang_alpha(c):
    """
    Renvoie le rang (entre 0 et 25) du caractère c
    dans l'ordre alphabétique

    Parametres:
        c (str): caractère
        Précondition : c caractère alphabétique majuscule
    Retour:
        (int)
    """
    # précondition
    assert ord('A') <= ord(c) <= ord('Z'), "il faut un caractère alphabétique majuscule"
    # à compléter


def histogramme(mot):
    """
    Renvoie l'histogramme des caractères d'un mot
    Précondition : mot contient uniquement des
    caractères en majuscule

    Paramètre:
        mot (str)
    Retour:
        tableau presence de taille 26
        presence[i] contient le nombre d'occurrences
        dans mot du caractère chr(i + ord('A'))
    """
    presence = [0 for _ in range(26)]
    # à compléter
    return presence


def verif_proposition(prop_joueur, secret):
    """
    Compare  la proposition du joueur et le secret
    Renvoie un couple :
        un booléen déterminant si prop_joueur == secret
        une chaine de caractères indiquant la distance
        entre prop_joueur et secret,
        avec les caractères MAL_PLACE, ABSENT ou le caractère trouvé

    Parametres:
        prop_joueur (str)
        secret (str)

    Retour:
        couple (boolean, str)
    """
    restant = histogramme(secret)
    tab_reponse = []
    # à compléter
    return (prop_joueur == secret, ''.join(tab_reponse))


def copie_tab(tab):
    """
    Renvoie une copie superficielle du tableau tab

    Parameter:
        tab (list)
    Retour:
        tab2: (list)
        Postcondition : id(tab2) != id(tab)
    """
    # à compléter
