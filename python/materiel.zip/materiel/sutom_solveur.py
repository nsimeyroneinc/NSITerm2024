# coding: utf-8

# %% Import des fonctions outils du module outils_sutom
from outils_sutom import *
import random

# %% Définition des constantes

DICO_PATH = "dico.txt"
ESSAI_MAX = 15
MAL_PLACE = '+'
ABSENT = '*'
DEBUG = True
ASSISTANCE = False


# %% Fonction pour définir le solveur
def tirage_mot_sans_remise(tab):
    """
    Extrait un mot au hasard du tableau de mots tab
    Précondition : tab est un tableau de mots (str) sans accents

    Parametres:
        tab (list): tableau de mots (str)

    Returns:
        un mot (str) choisi dans tab
    """
    # à compléter
    # Sélectionne un élément au hasard dans tab, l'extrait et le renvoie


def bien_place(caractere):
    """
    Détermine si un caractère lu dans la réponse de l'ordinateur est bien placé

    Parametre:
        caractere (str): le caractère lu

    Retour:
        (boolean)
    """
    # à compléter


def compatible(mot, prop_solveur, rep_ordi):
    """
    Détermine si mot est compatible avec la dernière réponse
    de l'ordinateur

    Parametres:
        mot (str): un mot pris dans le tableau des mots possibles
        prop_solveur (str): dernière proposition du solveur
        rep_ordi (str): dernière réponse de l'ordinateur

    Retour:
        (boolean)
    """
    # compatibilité avec le premier affichage de l'ordi (lettre 1 visible)
    if rep_ordi[1] == '?':
        return mot[0] == rep_ordi[0]
    # autres cas
    if len(mot) != len(rep_ordi):
        return False
    restant = histogramme(mot)
    # à compléter


def proposition_solveur(affichage):
    """
    #à compléter : comment le mot proposé par le solveur est-il choisi ?
    Affiche le mot sélectionné comme proposition du solveur
    Affiche la réponse de l'ordinateur

    Parametres:
        affichage (boolean) : détermine s'il y a des affichages avec print
    Retour:
        None
    """
    derniere_proposition = jeu["propositions"][-1]
    derniere_reponse = jeu["reponses"][-1]
    jeu["mots_possibles"] = [mot for mot in jeu["mots_possibles"] if compatible(mot, derniere_proposition, derniere_reponse)]
    prop = tirage_mot_sans_remise(jeu["mots_possibles"])
    if affichage:
        print("Proposition du solveur : ", prop)
    jeu["propositions"].append(prop)
    reponse_ordi(jeu["propositions"][-1], jeu["secret"], affichage)
    jeu["essai"] += 1


# %% Fonctions pour définir l'interface en ligne de commandes

def reponse_ordi(prop_solveur, secret, affichage=True):
    """
    Compare la proposition du joueur au secret
    Affiche la réponse de l'ordinateur
    Gère l'affichage de fin de partie
    Même fonction que dans sutom_solver.py

    Parametres:
        prop_joueur (str):
        secret (str):
        affichage (boolean) : détermine s'il y a des affichages avec print
    Retour:
        None
    """
    essai = jeu["essai"]
    jeu["gagne"], reponse = verif_proposition(prop_solveur, secret)
    jeu["reponses"].append(reponse)
    if affichage:
        print("Réponse de l'ordinateur : " + reponse)
    if jeu["gagne"]:
        if affichage:
            print("Gagné en " + str(essai) + " essais")
        jeu["verrou"] = True
    elif jeu["essai"] == jeu["essai_max"]:
        if affichage:
            print("Perdu en " + str(essai) + " essais")
        jeu["verrou"] = True


def partie(affichage=True):
    """
    Exécution d'une partie :
        réinitialisation des paramètres
        boucle de partie

    Parametre:
        affichage (boolean) : détermine s'il ya des affichages avec print
                              sinon exécution silencieuse

    Retour:
        renvoie un couple :
            jeu["gagne"] (boolean) : détermine si le solveur a gagné
            jeu["essai"] (int) : nombre d'essais
    """
    jeu["secret"] = tirage_mot(jeu["mots"])
    jeu["essai"] = 1
    jeu["gagne"] = False
    jeu["verrou"] = False
    jeu["propositions"] = ['']
    jeu["reponses"] = [jeu["secret"][0] + '?' * 5]
    jeu["mots_possibles"] = copie_tab(jeu["mots"])
    if affichage:
        print("Mot secret : " +  jeu["secret"][0] + "?" * (len(jeu["secret"]) - 1))
    while(not jeu["verrou"]) and (not jeu["gagne"]):
        proposition_solveur(affichage)
    if affichage:
        print("Le mot secret était " + jeu["secret"])
    return (jeu["gagne"], jeu["essai"] - 1)


# %% Interface

def interface_solveur():
    """
    Interface textuelle avec boucle de jeu
    Similaire à  celle de sutom_cli.py
    """
    # boucle principale d'interface en ligne de commande
    # même boucle que pour sutom_cli.py
    # à compléter

# %% Assistant solveur


def interface_assistant():
    """
    Interface textuelle pour assistant de résolution de sutom :
    
    Exemple :

    Saisir l'affichage de l'ordi : S???????
    Mot secret : S???????
    Proposition du solveur :  SCHERZOS
    Saisir l'affichage de l'ordi : S+*+****
    Proposition du solveur :  SARCELLE
    Saisir l'affichage de l'ordi : S**+*+*E
    Proposition du solveur :  SILICOSE
    Saisir l'affichage de l'ordi : S++*+**E
    Proposition du solveur :  SUPPLICE    
    """
    rep_ordi = input("Saisir l'affichage de l'ordi : ").rstrip()
    jeu["essai"] = 1
    jeu["gagne"] = False
    jeu["propositions"] = ['']
    jeu["reponses"] = [rep_ordi]
    jeu["mots_possibles"] = copie_tab(jeu["mots"])
    # à  compléter : boucle de partie


# %% Variable globale

# dictionnaire des paramètres du jeu
jeu = {"essai_max": ESSAI_MAX,
       "essai": 1,
       "mots_possibles": [],
       "propositions": [],
       "reponses": [],
       "gagne": False,
       "verrou": True
       }

# %% Programme principal

# ne s'exécute pas si le script
#  est importé dans un autre avec import sutom_solver
if __name__ == "__main__":
    taille_secret = int(input("Entrez la taille du mot secret : "))
    jeu["taille_secret"] = taille_secret
    jeu["mots"] = charger_dico(DICO_PATH, taille_secret)
    if ASSISTANCE:
        interface_assistant()
    else:
        interface_solveur()
