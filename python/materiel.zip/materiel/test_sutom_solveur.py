# coding: utf-8

# %% Import des fonctions à tester depuis le module outils_sutom

from outils_sutom import *


# %% Import des fonctions du module sutom_solver.py

from sutom_solveur import *

# %% Définitions des fonctions de test


def test_bien_place():
    """Tests unitaires pour la fonction bien_place"""
    print('-' * 80)
    print(test_bien_place.__doc__)
    assert not bien_place(MAL_PLACE)
    assert not bien_place(ABSENT)
    for i in range(26):
        assert bien_place(chr(ord('A') + i))
    print("Tests unitaires réussis pour la fonction bien_place")


def test_compatible():
    """Tests unitaires pour la fonction compatible"""
    print('-' * 80)
    print(test_compatible.__doc__)
    assert compatible("TROMPA", "TARAMA", "T*+**A")
    assert not compatible("TRAUMA", "TROMPA", "T++**A")
    assert compatible("TOPERA", "TROMPA", "T++**A")
    assert compatible("TUTORA", "TOPERA", "T+**RA")
    assert not compatible("TOMERA", "TOPERA", "T+**RA")
    print("Tests unitaires réussis pour la fonction compatible")


# %% Fonction de test de performance du solveur

def test_performance_solveur(nb_parties, taille_secret):
    """
    Test de performance du solveur
    Renvoie le nombre moyen d'essais pour trouver le mot secret
    de taille taille_secret sur un échantillon de nb_parties parties

    Parametres:
        nb_parties (int)
        taille_secret (int)

    Retour:
        Un couple :
            (float) : fréquence de victoires
            (float) : nombre moyen d'essais sur l'échantillon
    """    
    jeu["taille_secret"] = taille_secret
    jeu["mots"] = charger_dico(DICO_PATH, taille_secret)
    total_gagne = 0
    total_essais = 0
    # à compléter
    return (total_gagne / nb_parties, total_essais / nb_parties)


# %% Programme principal

# ne s'exécute pas si le script
#  est importé dans un autre avec import test_outils_sutom
if __name__ == "__main__":
    "Décommentez ce qui suit lorsque votre fonction est prête"
    #test_bien_place()    # 
    # test_compatible()
    # print('-' * 80)
    # print("Taille de mot secret = 6")
    # for k in range(1, 6):
    #     print('-' * 80)
    #     print(f"Test {k}/5 de performance du solveur sur 1000 parties (frequence succès, nb moyen essais):")
    #     print(test_performance_solveur(1000, 6))

# Exemple d'exécution pour le solveur du corrigé :
# -------------------------------------------------------------------------
# Tests unitaires pour la fonction bien_place
# Tests unitaires réussis pour la fonction bien_place
# -------------------------------------------------------------------------
# Tests unitaires pour la fonction compatible
# Tests unitaires réussis pour la fonction compatible
# -------------------------------------------------------------------------
# Taille de mot secret = 6
# -------------------------------------------------------------------------
# Test 1/5 de performance du solveur sur 1000 parties (frequence succès, nb moyen essais):
# (1.0, 4.31)
# -------------------------------------------------------------------------
# Test 2/5 de performance du solveur sur 1000 parties (frequence succès, nb moyen essais):
# (1.0, 4.298)
# -------------------------------------------------------------------------
# Test 3/5 de performance du solveur sur 1000 parties (frequence succès, nb moyen essais):
# (1.0, 4.304)
# -------------------------------------------------------------------------
# Test 4/5 de performance du solveur sur 1000 parties (frequence succès, nb moyen essais):
# (1.0, 4.345)
# -------------------------------------------------------------------------
# Test 5/5 de performance du solveur sur 1000 parties (frequence succès, nb moyen essais):
# (1.0, 4.387)

