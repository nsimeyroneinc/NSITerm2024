# coding: utf-8

# %% Import des fonctions outils

from outils_sutom import *


# %% Définition des constantes globales

DICO_PATH = "dico.txt"
ESSAI_MAX = 15
MAL_PLACE = '+'
ABSENT = '*'
DEBUG = True

# %% Définitions des fonctions pour l'interface en ligne de commande


def partie():
    """
    Exécution d'une partie :
        réinitialisation des paramètres
        boucle de partie
    Utilise la fonction  validation_joueur
    """
    jeu["secret"] = tirage_mot(jeu["mots"])
    jeu["essai"] = 1
    jeu["verrou"] = False
    jeu["gagne"] = False
    # à  compléter : boucle de partie


def validation_joueur():
    """
    Saisie d'une réponse du joueur humain
    Appel de la fonction reponse_ordi avec la proposition du joueur
    """
    print("Essai " + str(jeu["essai"]) + "/" + str(jeu["essai_max"]))
    proposition = input('Proposition du joueur : ').rstrip()
    # à compléter
    # demander la saisie d'une proposition
    # tant que la proposition n'est pas de la taille du secret
    reponse_ordi(proposition, jeu["secret"])
    if not jeu["verrou"]:
        jeu["essai"] = jeu["essai"] + 1


def reponse_ordi(prop_joueur, secret):
    """
    Compare la proposition du joueur au secret
    Affiche la réponse de l'ordinateur
    Gère l'affichage de fin de partie
    Utilise la fonction verif_proposition

    Parametres:
        prop_joueur (str):
        secret (str):
    Retour:
        None
    """
    essai = jeu["essai"]
    jeu["gagne"], reponse = verif_proposition(prop_joueur, secret)
    print("Réponse de l'ordinateur : " + reponse)
    if jeu["gagne"]:
        print("Gagné en " + str(essai) + " essais")
        jeu["verrou"] = True
    elif jeu["essai"] == jeu["essai_max"]:
        print("Perdu en " + str(essai) + " essais")
        jeu["verrou"] = True


def interface():
    """
    Interface textuelle avec boucle de jeu
    Utilise la fonction partie
    """
    continuer = True
    while continuer:
        rep = input("Nouvelle partie (o/n) ? ")
        taille_secret = int(input("Taille du mot secret ? "))
        jeu["mots"] = charger_dico(DICO_PATH, taille_secret)
        while rep.lower() not in "on":
            rep = input("Nouvelle partie (o/n) ? ")
        continuer = (rep.lower() == "o")
        if continuer:
            nb_essais = int(input("Nombre d'essais (1 -> " + str(ESSAI_MAX) + ") : "))
            while not(isinstance(nb_essais, int)
                      and 1 <= nb_essais <= ESSAI_MAX):
                nb_essais = int(input("Nombre d'essais (1 -> " + str(ESSAI_MAX) + ") : "))
            jeu["essai_max"] = nb_essais
            partie()

# %% Variable globale

# dictionnaire des paramètres du jeu


jeu =  {"essai_max": ESSAI_MAX,
        "essai": 1,
        "gagne": False,
        "verrou": True
        }


# %% Programme principal

# ne s'exécute pas si le script
#  est importé dans un autre avec import sutom_cli
if __name__ == "__main__":
    # boucle principale d'interface en ligne de commande
    interface()
