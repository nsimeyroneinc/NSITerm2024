# coding: utf-8

# %% Import des fonctions à tester depuis le module outils_sutom

from outils_sutom import *


# %% Définitions des fonctions de test

def test_charger_dico():
    """Tests unitaires pour la fonction charger_dico"""
    print('-' * 80)
    print(test_charger_dico.__doc__)
    tab_mots = charger_dico("dico.txt", 6)
    assert len(tab_mots) == 16103
    assert tab_mots[0] == "ABACAS"
    tab_mots = charger_dico("dico.txt", 7)
    assert len(tab_mots) == 29842
    assert tab_mots[0] == "ABACULE"
    tab_mots = charger_dico("dico.txt", 8)
    assert len(tab_mots) == 45632
    assert tab_mots[0] == "ABACULES"
    tab_mots = charger_dico("dico.txt", 9)
    assert len(tab_mots) == 57863
    assert tab_mots[0] == "ABAISSAIS"
    print("Tests unitaires réussis pour charger_dico")


def test_histogramme_dico():
    """Tests unitaires pour la fonction histogramme_dico"""
    print('-' * 80)
    print(test_histogramme_dico.__doc__)
    assert histogramme_dico("dico.txt") == {6: 16103, 7: 29842, 8: 45632, 9: 57863}
    print("Test unitaire réussi pour histogramme_dico")


def test_rang_alpha():
    """Tests unitaires pour la fonction rang_alpha"""
    print('-' * 80)
    print(test_rang_alpha.__doc__)
    assert rang_alpha('A') == 0
    assert rang_alpha('B') == 1
    assert rang_alpha('Z') == 25
    assert rang_alpha('J') == 9
    print("Tests unitaires réussis pour rang_alpha")


def test_histogramme():
    """Tests unitaires pour histogramme"""
    print('-' * 80)
    print(test_histogramme.__doc__)
    assert histogramme("DEBATS") == [1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0,
                                     0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
                                     0, 0, 0, 0]
    assert histogramme("INFOBULLE") == [0, 1, 0, 0, 1, 1, 0, 0, 1,
                                        0, 0, 2, 0, 1, 1, 0, 0, 0,
                                        0, 0, 1, 0, 0, 0, 0, 0]
    print("Tests unitaires réussis pour histogramme")


def test_verif_proposition():
    """Tests unitaires pour verif_proposition"""
    print('-' * 80)
    print(test_verif_proposition.__doc__)
    assert verif_proposition("POPLITE", "PETUNIA") == (False, "P***+++")
    assert verif_proposition("PRIRENT", "PETUNIA") == (False, "P*+*+++")
    assert verif_proposition("PATINES", "PETUNIA") == (False, "P+T+N+*")
    assert verif_proposition("PETUNIA", "PETUNIA") == (True, "PETUNIA")
    print("Tests unitaires réussis pour verif_proposition")


# %% Programme principal

# ne s'exécute pas si le script
#  est importé dans un autre avec import test_outils_sutom
if __name__ == "__main__":
    "Décommentez ce qui suit lorsque votre fonction est prête"
    # test_charger_dico()
    # test_histogramme_dico()
    # test_rang_alpha()
    # test_histogramme()
    # test_verif_proposition()
