# coding: utf-8

# %% Import des fonctions d'interface graphique du  module nsi_ui
from nsi_ui import *

# %% Import des fonctions outils du module outils_sutom
from outils_sutom import *

# %% Définition des constantes

DICO_PATH = "dico.txt"
ESSAI_MAX = 15
MAL_PLACE = '+'
ABSENT = '*'
DEBUG = True

# %% Définitions des fonctions pour l'interface graphique


def interface():
    """
    Définition et disposition en bloc
    des interacteurs de l'interface graphique
   	"""
    begin_horizontal()
    begin_vertical()
    for k in range(ESSAI_MAX):
        jeu["bloc_proposition"].append(entry("Proposition joueur " + str(k + 1)))
        jeu["bloc_reponse"].append(label("Réponse ordi " + str(k + 1) + " : " + "_ " * ESSAI_MAX))
    end_vertical()
    begin_vertical()
    jeu["taille_secret"] = slider("Taille du mot secret : ", 6, 9)
    jeu["bloc_annonce"] = label("Mot secret : " + "_ " * get_int(jeu["taille_secret"]))
    jeu["bloc_essai_max"] = slider("Nombre maximum d'essais : ", 1, ESSAI_MAX)
    jeu["bloc_jouer"] = button("Nouvelle partie", partie)
    jeu["bloc_gagne"] = label("Partie en cours")
    jeu["bloc_essai"] = label("Essai " + str(jeu["essai"]))
    jeu["bloc_validation"] = button("Valider proposition", validation_joueur)
    jeu["bloc_avertissement"] = label("")
    end_vertical()
    end_horizontal()
    main_loop()  # boucle gestionnaire d'événements


def partie():
    """
    Fonction de rappel pour le bouton jeu["bloc_jouer"] défini dans interface()
    les champs d'étiquettes label de jeu["bloc_proposition"] et jeu["bloc_reponse"]
    les variables d'une partie : jeu["secret"], jeu["verrou"], jeu["gagne"]
    jeu["essai"] et jeu["essai_max"]
    """
    jeu["mots"] = charger_dico(DICO_PATH, get_int(jeu["taille_secret"]))
    jeu["secret"] = tirage_mot(jeu["mots"])
    if DEBUG:
        print(jeu["secret"])
    jeu["verrou"] = False
    jeu["gagne"] = False
    jeu["essai"] = 1
    jeu["essai_max"] = get_int(jeu["bloc_essai_max"])
    set_text(jeu["bloc_annonce"],"Mot secret : "  + jeu["secret"][0] + "?" * (len(jeu["secret"]) - 1))
    for k in range(ESSAI_MAX):
        set_text(jeu["bloc_proposition"][k], "")
        set_text(jeu["bloc_reponse"][k], "Réponse ordi " + str(k + 1) + " : " + "_ " * len(jeu['secret']))
    set_text(jeu["bloc_essai"], "Essai " + str(jeu["essai"]) + "/" + str(jeu["essai_max"]))
    if DEBUG:
        print(jeu["secret"])


def validation_joueur():
    """
    Fonction de rappel du bouton jeu["bloc_validation"]
    Valide le choix du joueur :
        vérification que la saisie est cohérente avec la longueur du secret
        affichage de la réponse de l'ordinateur
    Utilise la fonction reponse_ordi
    """
    if not jeu["verrou"]:
        # effacer un avertissement précédent
        set_text(jeu["bloc_avertissement"], "") 
        set_text(jeu["bloc_essai"], "Essai " + str(jeu["essai"]) + "/" + str(jeu["essai_max"])) 
        essai = jeu["essai"]
        champ_proposition = jeu["bloc_proposition"][essai - 1]
        prop_joueur = get_string(champ_proposition)
        if (len(prop_joueur) != len(jeu['secret'])) or (prop_joueur[0] != jeu['secret'][0]):
            set_text(jeu["bloc_avertissement"], "Proposition incohérente")
            return
        reponse_ordi(prop_joueur, jeu["secret"])
        if not jeu["verrou"]:
            jeu["essai"] = jeu["essai"] + 1
        if DEBUG:
            print(jeu["essai"], jeu["gagne"])


def reponse_ordi(prop_joueur, secret):
    """
    Vérifie la proposition du joueur avec verif_proposition(prop_joueur, secret)
    Affiche la réponse de l'ordinateur dans jeu["bloc_reponse"][essai - 1]
    Vérifie si le joueur a gagné ou atteint le nombre maximum
    et met à jour l'affichage de fin de partie dans jeu["bloc_gagne"]
    et jeu["bloc_annonce"], verrouille alors le jeu avec jeu["verrou"] = True
    Utilise la fonction verif_proposition

    Parametres:
        prop_joueur (str): proposition du joueur
        secret (str): mot secret
    Retour:
        None
    """
    essai = jeu["essai"]
    bloc_reponse_courant = jeu["bloc_reponse"][essai - 1]
    jeu["gagne"], reponse = verif_proposition(prop_joueur, secret)
    set_text(bloc_reponse_courant, "Réponse ordi " + reponse)
    # à compléter : gestion de la fin de partie

# %% Variable globale
# dictionnaire des paramètres du jeu
jeu =  {"essai_max": ESSAI_MAX,
        "essai": 1,
        "bloc_reponse": [],
        "bloc_proposition": [],
        "gagne": False,
        "verrou": True
        }

if __name__ == "__main__":
    interface()  # Interface graphique
