from .gomoku import Gomoku
